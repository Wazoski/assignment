// LinkLayer.cpp: implementation of the CLinkLayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PacketSender.h"
#include "LinkLayer.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLinkLayer::CLinkLayer( char* pName )
: CBaseLayer( pName )
{
	ResetHeader( ) ;
}

CLinkLayer::~CLinkLayer()
{
}

void CLinkLayer::ResetHeader()
{
	m_sHeader.link_packet_type = ntohs(0x0004);
	m_sHeader.link_addr_type =  ntohs(0x0001);
	m_sHeader.link_addr_length =  ntohs(0x0006);
	m_sHeader.link_proto = ntohs(ETHER_PROTO_TYPE_IP) ; // 0x0800
	memset(m_sHeader.link_data,'\0',ETHER_MAX_DATA_SIZE);
}

u_char* CLinkLayer::GetEnetSrcAddress() // Ethernet Source Address
{
	return m_sHeader.link_srcaddr.addrs;
}

void CLinkLayer::SetEnetSrcAddress(u_char *pAddress)
{
	// �̴��� �ּ� 12�ڸ��� �����´�. (NI Layer���� �����´�.)
	ETHERNET_ADDR src_ether;
	src_ether.addr0 = pAddress[0];
	src_ether.addr1 = pAddress[1];
	src_ether.addr2 = pAddress[2];
	src_ether.addr3 = pAddress[3];
	src_ether.addr4 = pAddress[4];
	src_ether.addr5 = pAddress[5];

	memcpy( m_sHeader.link_srcaddr.addrs, pAddress, 6 ) ;
}

BOOL CLinkLayer::Send(u_char *ppayload, int nlength)
{
	memcpy( m_sHeader.link_data , ppayload, nlength ) ;

	BOOL bSuccess = FALSE ;
	bSuccess = mp_UnderLayer->Send((u_char*) &m_sHeader,nlength + LINK_HEADER_SIZE);

	return bSuccess ;
}
	
BOOL CLinkLayer::Receive( u_char* ppayload )
{
	// ���� �������� ���� payload�� ���� ������ header������ �°� ����.
	PETHERNET_HEADER pFrame = (PETHERNET_HEADER) ppayload ;

	BOOL bSuccess = FALSE ;

	// ������ �� Ethernet Address�� �ƴϸ� discard �Ѵ�.
//	if(!memcmp((char *)pFrame->enet_dstaddr.addrs,(char *)m_sHeader.link_srcaddr.addrs,6))
//	{
		bSuccess = mp_aUpperLayer[0]->Receive((u_char*) pFrame->enet_data);
//	}
	return bSuccess ;
}
